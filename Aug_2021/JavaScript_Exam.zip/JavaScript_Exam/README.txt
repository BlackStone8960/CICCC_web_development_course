Hi Ivan, 

I have solved task 1, so could you check it when you have time?
Thank you,

Taichi Ishiguro